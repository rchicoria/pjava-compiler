class test3
{

	static int b = 0;
	
	public static int func(double a, double b, int c) {
	    return 0;
	}
	
	public static void main(String [] args) {
		int a=2, b=3;
		b=1;
		System.out.println(2+4);
		if(true && a==1 || !false)
		    b=0;
		for(a=1; a<10; a++)
		    b=1;
	    b=33;
		System.out.println(2+4);
	}

}
